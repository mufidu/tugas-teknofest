# *****
# ****
# ***
# **
# *

N = int(input("Masukkan angka: "))

for i in range(N, 0, -1):
    print("*"*i)